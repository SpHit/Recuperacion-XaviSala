package net.lupin;

import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;

/**
 * Generador de contrasenyes "automàtic".
 * 
 * @author xavier
 *
 */
public class Generador {
	
	private static final int NUMCARACTERS = 10;

	private static String BASE = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabsdefghijklmnopqrstuvwxyz";
	

	public static final String ERROR = "Error";


	public String mostra(String usuari) {
		if (usuari != null && !usuari.isEmpty()) {
			return generaCodi(usuari);
		}		
		return ERROR;
	}
	
	private String generaCodi(String usuari) {
		
		StringBuilder resultat = new StringBuilder();
		
		for(int i=0; i<NUMCARACTERS; i++) {
			String[] separats = separaSerial(i+1, usuari);
			
			int codi = 0;
			int hash = nthPrime(i);
			for(String separat: separats) {
				
				for(char c: separat.toCharArray()) {
					hash = hash * nthPrime(30+i) +  c;
				}
				codi = (codi + hash) % BASE.length();				
			}
			if (codi < 0) {
				codi = Math.abs(codi);
			}
			resultat = resultat.append(BASE.charAt(codi));
		}
		
		return resultat.toString();
	}

	
	private String[] separaSerial(int xifres, String contrasenya) {
		return
			    Iterables.toArray(
			        Splitter
			            .fixedLength(xifres)
			            .split(contrasenya),
			        String.class
			    );			    
	}

	public static int nthPrime(int n) {
	    int candidate, count;
	    for(candidate = 2, count = 0; count < n; ++candidate) {
	        if (isPrime(candidate)) {
	            ++count;
	        }
	    }
	    return candidate-1;
	}
	
	private static boolean isPrime(long n) {
	    if(n < 2)
	        return false;

	    for (long i = 2; i * i <= n; i++) {
	        if (n % i == 0)
	            return false;
	    }
	    return true;
	}
	
}
